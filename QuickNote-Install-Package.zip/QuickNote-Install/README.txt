QuickNote 安裝包
1. 下載 QuickNote_0.1.0_aarch64.dmg 到此資料夾
2. 雙擊 quick-install.sh 或在終端機執行 ./quick-install.sh
