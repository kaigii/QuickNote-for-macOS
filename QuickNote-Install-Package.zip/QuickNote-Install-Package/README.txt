🚀 QuickNote 一鍵安裝包

使用方法：
1. 解壓縮這個資料夾
2. 雙擊 install.sh
3. 按照提示操作

或者：
1. 開啟終端機
2. cd 到此資料夾
3. chmod +x install.sh
4. ./install.sh

腳本會自動：
- 下載 QuickNote DMG 檔案
- 移除安全限制
- 安裝到 Applications
- 啟動應用程式

就是這麼簡單！🎉 